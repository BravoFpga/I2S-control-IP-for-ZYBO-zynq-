#include <stdio.h>
#include "xparameters.h"
#include "xsdps.h"
#include "ff.h"
#include "xil_cache.h"

#include "my_i2s.h"
#include "ssm2603.h"

u8  wv[100000000]; // wav data pool
u8  plist[2048];  // playlist
/****************************************** 
  - playlist example -

   1.wav bravo_music
   2.wav nanchatte_music
   3.wav i_love_music
         :
       so on
         :

   *. the sampling rate assumes 44.1K.
******************************************/

/******************************************
   Push botton 
    BTN0 ... volume--
    BTN1 ... volume++
    BTN2 ... skip music
******************************************/
struct sc_gpio {
   volatile u32 gpio_data;
   volatile u32 gpio_tri;
   volatile u32 gpio2_data;
   volatile u32 gpio2_tri;
} *BTNs_port = XPAR_AXI_GPIO_0_BASEADDR,
  *LEDs_port = XPAR_AXI_GPIO_2_BASEADDR;

int main() 
{
   int 	 i;
   char    dac_volume = 0x69;

   Xil_ICacheEnable();
   Xil_DCacheEnable();
   
   BTNs_port->gpio_tri = 0xffffffff;
   LEDs_port->gpio_tri = 0x0;

   SSM2603_init();

   SSM2603_REGWRT(0x02, dac_volume);
   SSM2603_REGWRT(0x03, dac_volume);

   pI2S->CTL = DAC_MUTE | ADC_MUTE;

   LEDs_port->gpio_data = 0x55;

   pI2S->DAC_BGN = (u32)wv;
   pI2S->DAC_END = (u32)wv + sizeof(wv);
   pI2S->DAC_THR = (u32)wv + sizeof(wv)/2;

   pI2S->ADC_BGN = (u32)wv;
   pI2S->ADC_END = (u32)wv + sizeof(wv);
   pI2S->ADC_THR = (u32)wv + sizeof(wv)/2;

   pI2S->INT = pI2S->INT;

   // REC START
   pI2S->CTL = RATE_44100| ADC_DMA_EN | ADC_DMA_CIRCULATION_MODE | DAC_MUTE;

   for(i=0;i<100000;i++);

   // PLAYBACK START
   pI2S->CTL = RATE_44100| ADC_DMA_EN | ADC_DMA_CIRCULATION_MODE |
		                    DAC_DMA_EN | DAC_DMA_CIRCULATION_MODE;

   u32 btn;
   while (1) {
     printf("--> pI2S->DBG1 =%08x pI2S->DBG2 =%08x pI2S->DBG3 =%08x pI2S->CTL=%08x\r",
     		pI2S->DBG1,pI2S->DBG2,pI2S->DBG3,pI2S->CTL);
     btn = BTNs_port->gpio_data;
     if (btn & 2) {
       while (BTNs_port->gpio_data);
       if (dac_volume < 0x7F) {
  		  dac_volume = (dac_volume + 1) & 0x7F;
         SSM2603_REGWRT(0x02, dac_volume);
         SSM2603_REGWRT(0x03, dac_volume);
       }
     } // if (btn & 2) ...

     if (btn & 1) {
        while (BTNs_port->gpio_data);
        if (dac_volume > 0) {
  		   dac_volume = (dac_volume - 1) & 0x7F;
          SSM2603_REGWRT(0x02, dac_volume);
          SSM2603_REGWRT(0x03, dac_volume);
        }
      } // if (btn & 1) ...

      if (btn & 4) {
        while (BTNs_port->gpio_data);
        break;
      } // if (btn & 4) ...
   } // while (1) ...

   pI2S->CTL = DAC_MUTE | ADC_MUTE;
   pI2S->INT = pI2S->INT;

   Xil_DCacheDisable();
   Xil_ICacheDisable();

   return 0;
}
