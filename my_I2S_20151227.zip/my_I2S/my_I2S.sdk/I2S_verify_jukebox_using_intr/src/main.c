#include <stdio.h>
#include "xparameters.h"
#include "xsdps.h"
#include "ff.h"
#include "xil_cache.h"
#include "my_i2s.h"
#include "ssm2603.h"

//--------------------------------------------------------------------------------

FIL fil;

#define	WV_BUFF_SIZE	2048
u8 wv[WV_BUFF_SIZE]; // wav data pool

u8 plist[2048];  // playlist
/****************************************** 
 - playlist example -

 1.wav bravo_music
 2.wav nanchatte_music
 3.wav i_love_music
 :
 so on
 :

 *. the sampling rate assumes 44.1K.
 ******************************************/

/******************************************
 Push botton
 BTN0 ... volume--
 BTN1 ... volume++
 BTN2 ... skip music
 ******************************************/
struct sc_gpio {
	volatile u32 gpio_data;
	volatile u32 gpio_tri;
	volatile u32 gpio2_data;
	volatile u32 gpio2_tri;
}*BTNs_port = XPAR_AXI_GPIO_0_BASEADDR, *LEDs_port = XPAR_AXI_GPIO_2_BASEADDR;

//--------------------------------------------------------------------------------
#include "xil_exception.h"
#include "xscuwdt.h"
#include "xscugic.h"

#define	INTC_DEVICE_ID	XPAR_SCUGIC_SINGLE_DEVICE_ID
#define	I2SIntrId    	XPAR_FABRIC_I2S_CTL_0_S_IRQ_INTR

static XScuGic IntcInstance, *IntcInstancePtr = &IntcInstance;

static void I2SIntrHandler(void *CallBackRef);
static int I2SSetupIntrSystem(void);
static void I2SEnableInterrupt(void);
static void I2SDisableIntrSystem(void);

static int I2SSetupIntrSystem() {
	int Status;

	// GIC config
	XScuGic_Config *IntcConfig;

	// Initialize the interrupt controller driver 
	IntcConfig = XScuGic_LookupConfig(INTC_DEVICE_ID);
	if (IntcConfig == NULL) return XST_FAILURE;

	Status = XScuGic_CfgInitialize(IntcInstancePtr, IntcConfig, IntcConfig->CpuBaseAddress);
	if (Status != XST_SUCCESS) return XST_FAILURE;

	Xil_ExceptionInit();

	/*
	 * Connect the interrupt controller handler to the
	 * hardware interrupt handling logic in the processor.
	 */
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,
		(Xil_ExceptionHandler) XScuGic_InterruptHandler, IntcInstancePtr);

	/*
	 * Connect the device driver handler that will be called when an
	 * interrupt for the device occurs.
	 */
	Status = XScuGic_Connect(IntcInstancePtr, I2SIntrId,
                                 (Xil_ExceptionHandler) I2SIntrHandler, NULL);

	if (Status != XST_SUCCESS) return Status;

	// Enable the interrupt for the device.
	XScuGic_Enable(IntcInstancePtr, I2SIntrId);

	// Enable the I2S interrups for playback DMA.
	I2SEnableInterrupt();

	// Enable interrupts in the Processor.
	Xil_ExceptionEnable();

	return XST_SUCCESS;
}

static void I2SEnableInterrupt(void) {
	pI2S->INT  = I2S_ALL_IRQ_MASK | I2S_ALL_IRQ_CLR;
	pI2S->INT &= ~(DAC_DMA_THR_IRQ_MASK | DAC_DMA_END_IRQ_MASK);
}

static void I2SDisableIntrSystem(void) {
	pI2S->INT = I2S_ALL_IRQ_MASK | I2S_ALL_IRQ_CLR;
	pI2S->CTL = RATE_44100 | ADC_MUTE | DAC_MUTE;

	XScuGic_Disconnect(IntcInstancePtr, I2SIntrId);
}

/*
 * Interrupt Handler
 */
static void I2SIntrHandler(void *CallBackRef) {

	UINT r_len, i;

	if (pI2S->INT & DAC_DMA_THR_IRQ) {
		pI2S->INT = (pI2S->INT & 0xffff0000)| DAC_DMA_THR_IRQ;

		if (f_read(&fil, wv, WV_BUFF_SIZE / 2, &r_len)) {
		   printf("f_read failed\n");
		   pI2S->INT = I2S_ALL_IRQ_MASK | I2S_ALL_IRQ_CLR;
		}
		for (i = r_len; i < WV_BUFF_SIZE/2; i++) wv[i] = 0;

	} else if (pI2S->INT & DAC_DMA_END_IRQ) {
		pI2S->INT = (pI2S->INT & 0xffff0000)| DAC_DMA_END_IRQ;

		if (f_read(&fil, &wv[WV_BUFF_SIZE / 2], WV_BUFF_SIZE / 2, &r_len)) {
		   printf("f_read failed\n");
		   pI2S->INT = I2S_ALL_IRQ_MASK | I2S_ALL_IRQ_CLR;
		}
		for (i = r_len; i < WV_BUFF_SIZE/2; i++) wv[(WV_BUFF_SIZE/2)+i] = 0;

	} else {
		printf("unexpected interrupt: %08x\n",pI2S->INT);
		pI2S->INT = I2S_ALL_IRQ_MASK | I2S_ALL_IRQ_CLR;
	}

	if (f_eof(&fil)) {
	   pI2S->INT = I2S_ALL_IRQ_MASK;
	   pI2S->CTL = RATE_44100 | ADC_MUTE | DAC_DMA_EN;
	}

	Xil_DCacheFlush();
}
//--------------------------------------------------------------------------------

int main() {
	UINT i;
	char *pidx;
	char fn[256];
	char title[256];
	FATFS fatfs;
	FRESULT fres;
	char dac_volume = 0x69;
	u32 btn;

	Xil_ICacheEnable();
	Xil_DCacheEnable();

	BTNs_port->gpio_tri = 0xffffffff;
	LEDs_port->gpio_tri = 0x0;

	SSM2603_init();

	SSM2603_REGWRT(0x02, dac_volume);
	SSM2603_REGWRT(0x03, dac_volume);

	pI2S->DAC_BGN = (unsigned int)wv;
	pI2S->DAC_THR = (unsigned int)&wv[(WV_BUFF_SIZE / 2)-4];
	pI2S->DAC_END = (unsigned int)&wv[WV_BUFF_SIZE-4];

	pI2S->CTL = DAC_MUTE | ADC_MUTE;

	I2SSetupIntrSystem();

	if (f_mount(&fatfs, "0", 1) != FR_OK) {
		printf("f_mount failed\n");
		return XST_FAILURE;
	}

	if (f_open(&fil, "playlist.txt", FA_READ)) {
		printf("f_open failed\n");
		return XST_FAILURE;
	}

	if ((fres = f_lseek(&fil, 0))) {
		printf("f_lseek failed\n");
		return XST_FAILURE;
	}

	if ((fres = f_read(&fil, plist, fil.fsize, &i))) {
		printf("f_read failed\n");
		return XST_FAILURE;
	}

	fres = f_close(&fil);

	pidx = (char *)plist;

	while (1) {
		LEDs_port->gpio_data = (u32)(pidx + 1);

		if (sscanf(pidx, "%s %s", fn, title) == 0) {
			pidx = (char *)plist;
			if (sscanf(pidx, "%s %s", fn, title) == 0)
				break;
		}

		pidx = strchr(pidx, '\n');
		if (pidx == 0)
		   pidx = (char *)plist;
		else
		   pidx++;

		if ((fres = f_open(&fil, fn, FA_READ))) {
		   printf("f_open failed\n");
		   return XST_FAILURE;
		}

		printf("file %s (%s)\n", fn, title);
		printf("now loading ...\n");

		if ((fres = f_lseek(&fil, 0))) {
		  printf("f_lseek failed\n");
		  return XST_FAILURE;
		}

		if ((fres = f_read(&fil, wv, WV_BUFF_SIZE, &i))) {
		  printf("f_read failed\n");
		  return XST_FAILURE;
		}

		for (i = 0; i < WV_BUFF_SIZE; i++) {
		  if (!strncasecmp("data",(const char *)&wv[i], 4))
		    break;
		}

		if (i == WV_BUFF_SIZE) {
		  printf("missing data chunk\n");
		  return XST_FAILURE;
		}

		if ((fres = f_lseek(&fil, i + 8))) {
		  printf("f_lseek failed\n");
		  return XST_FAILURE;
		}

		for (i=0;i<WV_BUFF_SIZE;i++) wv[i] = 0;
/*
		if ((fres = f_read(&fil, wv, WV_BUFF_SIZE, &i))) {
		  printf("f_read failed\n");
		  return XST_FAILURE;
		}
*/
		Xil_DCacheFlush();


		printf("play start ...\n");
		I2SEnableInterrupt();
		pI2S->CTL = RATE_44100 | ADC_MUTE | DAC_DMA_EN | DAC_DMA_CIRCULATION_MODE;

		while (1) {
			printf("--> pI2S->PB_DBG1 =%08x pI2S->PB_DBG2 =%08x pI2S->CTL=%08x\r", pI2S->PB_DBG1,pI2S->PB_DBG2,pI2S->CTL);

			btn = BTNs_port->gpio_data;
			if (btn & 2) {
				while (BTNs_port->gpio_data)
					;
				if (dac_volume < 0x7F) {
					dac_volume = (dac_volume + 1) & 0x7F;
					SSM2603_REGWRT(0x02, dac_volume);
					SSM2603_REGWRT(0x03, dac_volume);
				}
			}
			if (btn & 1) {
				while (BTNs_port->gpio_data)
					;
				if (dac_volume > 0) {
					dac_volume = (dac_volume - 1) & 0x7F;
					SSM2603_REGWRT(0x02, dac_volume);
					SSM2603_REGWRT(0x03, dac_volume);
				}
			}
			if (btn & 4) {
				while (BTNs_port->gpio_data);
				break;
			}

			if (!(pI2S->CTL & DAC_DMA_EN)) {
			  break;
			}
		}
		printf("\ndone\n");

		pI2S->CTL = DAC_MUTE | ADC_MUTE;
		pI2S->INT = I2S_ALL_IRQ_MASK | I2S_ALL_IRQ_CLR;
	}

	I2SDisableIntrSystem();

	Xil_DCacheDisable();
	Xil_ICacheDisable();

	return 0;
}
