#include <stdio.h>
#include "xparameters.h"
#include "xsdps.h"
#include "ff.h"
#include "xil_cache.h"

#include "my_i2s.h"
#include "ssm2603.h"

u8  wv[100000000]; // wav data pool
u8  plist[2048];  // playlist
/****************************************** 
  - playlist example -

   1.wav bravo_music
   2.wav nanchatte_music
   3.wav i_love_music
         :
       so on
         :

   *. the sampling rate assumes 44.1K.
******************************************/

/******************************************
   Push botton 
    BTN0 ... volume--
    BTN1 ... volume++
    BTN2 ... skip music
******************************************/
struct sc_gpio {
   volatile u32 gpio_data;
   volatile u32 gpio_tri;
   volatile u32 gpio2_data;
   volatile u32 gpio2_tri;
} *BTNs_port = XPAR_AXI_GPIO_0_BASEADDR,
  *LEDs_port = XPAR_AXI_GPIO_2_BASEADDR;

int main() 
{
   int 	   i;
   char    *pidx;
   char    fn[256];
   char    title[256];
   FIL 	   fil;
   FATFS   fatfs;
//   FRESULT Res;
   char    dac_volume = 0x69;
//   char    dac_volume = 0x7F;

   Xil_ICacheEnable();
   Xil_DCacheEnable();
   
   BTNs_port->gpio_tri = 0xffffffff;
   LEDs_port->gpio_tri = 0x0;

   SSM2603_init();

   SSM2603_REGWRT(0x02, dac_volume);
   SSM2603_REGWRT(0x03, dac_volume);

   pI2S->CTL = DAC_MUTE | ADC_MUTE;
//printf("pI2S->PB_DBG1 =%08x\n",pI2S->PB_DBG1);

   if (f_mount(&fatfs, "0", 1) != FR_OK) {
     printf("f_mount failed\n");
     return XST_FAILURE;
   }

   if (f_open(&fil, "playlist.txt", FA_READ)) {
     printf("f_open failed\n");
     return XST_FAILURE;
   }

   if (f_lseek(&fil, 0)) {
     printf("f_lseek failed\n");
     return XST_FAILURE;
   }

   if (f_read(&fil, plist, fil.fsize, (UINT *)&i)) {
     printf("f_read failed\n");
     return XST_FAILURE;
   }

   f_close(&fil);

   pidx = (char *)plist;
   while (1) {
       LEDs_port->gpio_data = (u32)(pidx + 1);

       if (sscanf(pidx,"%s %s",fn,title) == 0) {
         pidx = (char *)plist;
         if (sscanf(pidx,"%s %s",fn,title) == 0) break;
        }
       
       pidx = strchr(pidx,'\n');
       if (pidx ==0) 
         pidx = (char *)plist;
       else
         pidx++;
       
       if (f_open(&fil, fn, FA_READ)) {
         printf("f_open failed\n");
         return XST_FAILURE;
        }
       
        printf("file %s (%s)\n", fn, title);
        printf("now loading ...\n");
       
        if (f_lseek(&fil, 0)) {
          printf("f_lseek failed\n");
          return XST_FAILURE;
        }
       
       if (f_read(&fil, wv, fil.fsize, (UINT *)&i)) {
          printf("f_read failed\n");
          return XST_FAILURE;
        }

        for (i=0;i<(fil.fsize-4);i++) {
          if (!strncasecmp("data",(const char *)&wv[i],4)) break;
        }
        if (i == (fil.fsize-4)) {
          printf("missing data chunk\n");
          return XST_FAILURE;
        }
       
       u32 bgn = (u32)&wv[i+8];
       pI2S->DAC_BGN = bgn;
       u32 len = *(u32 *)&wv[i+4];
       pI2S->DAC_END = bgn+len;
       pI2S->DAC_THR = bgn+(len/2);

printf("pI2S->PB_DBG1 =%08x\n",pI2S->PB_DBG1);
       
       printf("play start ...\n");
       pI2S->INT = pI2S->INT;
       pI2S->CTL = RATE_44100|ADC_MUTE|DAC_DMA_EN;
printf("pI2S->PB_DBG1 =%08x\n",pI2S->PB_DBG1);

       
       u32 btn;
       while (1) {
         printf("--> pI2S->PB_DBG1 =%08x pI2S->PB_DBG2 =%08x pI2S->CTL=%08x\r",
        		 	 pI2S->PB_DBG1,pI2S->PB_DBG2,pI2S->CTL);
         btn = BTNs_port->gpio_data;
	 if (btn & 2) {
	    while (BTNs_port->gpio_data);
	    if (dac_volume < 0x7F) {
	      dac_volume = (dac_volume + 1) & 0x7F;
	      SSM2603_REGWRT(0x02, dac_volume);
	      SSM2603_REGWRT(0x03, dac_volume);
	    }
	 }
	 if (btn & 1) {
	    while (BTNs_port->gpio_data);
	    if (dac_volume > 0) {
	      dac_volume = (dac_volume - 1) & 0x7F;
	      SSM2603_REGWRT(0x02, dac_volume);
	      SSM2603_REGWRT(0x03, dac_volume);
	    }
	  }
	  if (btn & 4) {
	    while (BTNs_port->gpio_data);
	    break;
	  }
	  if (pI2S->INT & DAC_DMA_END_IRQ) {
	    break;
	  }
       }
       printf("\ndone\n");
printf("pI2S->PB_DBG1 =%08x\n",pI2S->PB_DBG1);

        pI2S->CTL = DAC_MUTE | ADC_MUTE;
        printf("mute\n");
printf("pI2S->PB_DBG1 =%08x\n",pI2S->PB_DBG1);

        pI2S->INT = pI2S->INT;
        printf("INT clear\n");
printf("pI2S->PB_DBG1 =%08x\n",pI2S->PB_DBG1);

   }

   Xil_DCacheDisable();
   Xil_ICacheDisable();

   return 0;
}
