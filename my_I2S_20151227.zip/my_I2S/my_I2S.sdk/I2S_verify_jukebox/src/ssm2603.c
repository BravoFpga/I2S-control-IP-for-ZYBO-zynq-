#include "xparameters.h"
#include "xil_cache.h"
#include "my_i2s.h"

struct st_I2S *pI2S = (struct st_I2S *)XPAR_I2S_CTL_0_BASEADDR;

void SSM2603_REGWRT(u32 Ra, u32 Wd)
{
   pI2S->I2C_RA = (Ra<<1) | ((Wd >> 8) & 1);
   pI2S->I2C_RD = Wd;
   pI2S->I2C_CA = I2C_WRITE;
   while (pI2S->I2C_ST);
}

u32 SSM2603_REGRD(u32 Ra)
{
   pI2S->I2C_RA = Ra<<1;
   pI2S->I2C_RD = 0;
   pI2S->I2C_CA = I2C_READ;
   while (pI2S->I2C_ST);
   return pI2S->I2C_RD;
}

void SSM2603_init()
{
   int i;

   // Power and Reset order is very important !
   // The Reset must be issued after the Power.
   SSM2603_REGWRT(0x06, 0x72); // Power
   SSM2603_REGWRT(0x0F, 0x00); // Reset

   SSM2603_REGWRT(0x00, 0x17); // Lch ADC input volume
   SSM2603_REGWRT(0x01, 0x17); // Rch ADC input volume
   SSM2603_REGWRT(0x02, 0x69); // Lch DAC volume
   SSM2603_REGWRT(0x03, 0x69); // Rch DAC volume
   SSM2603_REGWRT(0x04, 0x10); // Analog audio path
   SSM2603_REGWRT(0x05, 0x00); // Digital audio path
   SSM2603_REGWRT(0x07, 0x02); // Digital audio I/F
   SSM2603_REGWRT(0x08, 0x00); // Sampling rate (48KHz)
   SSM2603_REGWRT(0x10, 0x7B); // ALC Control 1
   SSM2603_REGWRT(0x11, 0x32); // ALC Control 2
   SSM2603_REGWRT(0x12, 0x00); // Noise Gate

   // wait (approx.) 100ms
   // usleep(100000);
   for (i=0;i<1700;i++) SSM2603_REGRD(0x09);

   SSM2603_REGWRT(0x09, 0x01); // Active
   SSM2603_REGWRT(0x06, 0x62); // 

   /*
   // dump
   for (i=0;i<0x13;i=(i==0x09)? 0x0F:i+1)
   {
       printf("SSM2603.R%d = %08X\n",i, SSM2603_REGRD(i));
   }
   */
}

