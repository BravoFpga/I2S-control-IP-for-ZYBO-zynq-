#ifndef MY_I2S_H
#define MY_I2S_H

struct st_I2S {
        volatile unsigned int CTL;
        volatile unsigned int INT;
        volatile unsigned int DAC_DATA;
        volatile unsigned int ADC_DATA;
        volatile unsigned int DAC_BGN;
        volatile unsigned int DAC_END;
        volatile unsigned int DAC_THR;
        volatile unsigned int DAC_CUR;
        volatile unsigned int ADC_BGN;
        volatile unsigned int ADC_END;
        volatile unsigned int ADC_THR;
        volatile unsigned int ADC_CUR;
        volatile unsigned int I2C_RA;
        volatile unsigned int I2C_RD;
        volatile unsigned int I2C_CA;
        volatile unsigned int I2C_ST;
        volatile unsigned int PB_DBG1;
        volatile unsigned int PB_DBG2;
        volatile unsigned int PB_DBG3;
};

#define	DAC_MUTE	0x01
#define	DAC_DMA_EN	0x02
#define	DAC_DMA_CIRCULATION_MODE 0x04

#define	ADC_MUTE	0x10
#define	ADC_DMA_EN	0x20
#define	ADC_DMA_CIRCULATION_MODE 0x40

#define	RATE_8000	0x000
#define	RATE_11025 	0x100
#define	RATE_12000	0x200
#define	RATE_16000	0x300
#define	RATE_22050	0x400
#define	RATE_24000	0x500
#define	RATE_32000	0x600
#define	RATE_44100	0x700
#define	RATE_48000	0x800
#define	RATE_88200	0x900
#define	RATE_96000	0xA00

#define	DAC_IRQ		0x01
#define	ADC_IRQ		0x02
#define	DAC_DMA_THR_IRQ	0x04
#define	DAC_DMA_END_IRQ	0x08
#define	ADC_DMA_THR_IRQ	0x10
#define	ADC_DMA_END_IRQ	0x20
#define I2S_ALL_IRQ_CLR 0x3F

#define	DAC_RDY_RAW	0x100
#define	ADC_RDY_RAW	0x200

#define	DAC_IRQ_MASK		0x010000
#define	ADC_IRQ_MASK		0x020000
#define	DAC_DMA_THR_IRQ_MASK	0x040000
#define	DAC_DMA_END_IRQ_MASK	0x080000
#define	ADC_DMA_THR_IRQ_MASK	0x100000
#define	ADC_DMA_END_IRQ_MASK	0x200000
#define I2S_ALL_IRQ_MASK	0x3F0000

#define	I2C_WRITE	0x34
#define	I2C_READ	0x35

#endif
