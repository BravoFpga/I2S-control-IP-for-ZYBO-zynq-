#ifndef ssm2603_H 
#define ssm2603_H 

#include "my_i2s.h"

extern struct st_I2S *pI2S;

void SSM2603_REGWRT(u32 Ra, u32 Wd);
u32 SSM2603_REGRD(u32 Ra);
void SSM2603_init(void);

#endif
