
#include <stdio.h>
#include "xparameters.h"
#include "xil_cache.h"
#include "my_i2s.h"
#include "impulse.h"

struct st_I2S *pI2S = (struct st_I2S *)XPAR_I2S_CTL_0_BASEADDR;

void SSM2603_REGWRT(u32 Ra, u32 Wd)
{
   pI2S->I2C_RA = (Ra<<1) | ((Wd >> 8) & 1);
   pI2S->I2C_RD = Wd;
   pI2S->I2C_CA = I2C_WRITE;
   while (pI2S->I2C_ST);
}

u32 SSM2603_REGRD(u32 Ra)
{
   pI2S->I2C_RA = Ra<<1;
   pI2S->I2C_RD = 0;
   pI2S->I2C_CA = I2C_READ;
   while (pI2S->I2C_ST);
   return pI2S->I2C_RD;
}

void SSM2603_init()
{
   int i;
   SSM2603_REGWRT(0x0F, 0x00); // Reset

   SSM2603_REGWRT(0x06, 0x72); // Power
   SSM2603_REGWRT(0x00, 0x97); // Lch ADC input volume
   SSM2603_REGWRT(0x01, 0x97); // Rch ADC input volume
   SSM2603_REGWRT(0x02, 0x7F); // Lch DAC volume
   SSM2603_REGWRT(0x03, 0x7F); // Rch DAC volume
   SSM2603_REGWRT(0x04, 0x10); // Analog audio path
   SSM2603_REGWRT(0x05, 0x00); // Digital audio path
   SSM2603_REGWRT(0x07, 0x02); // Digital audio I/F
   SSM2603_REGWRT(0x08, 0x00); // Sampling rate (48KHz)
   SSM2603_REGWRT(0x10, 0x7B); // ALC Control 1
   SSM2603_REGWRT(0x11, 0x32); // ALC Control 2
   SSM2603_REGWRT(0x12, 0x00); // Noise gate

   // wait (approx.) 100ms
   // usleep(100000);
   for (i=0;i<1700;i++) SSM2603_REGRD(0x09);

   SSM2603_REGWRT(0x09, 0x01); // Active
   SSM2603_REGWRT(0x06, 0x62); // 
}

int main() 
{
   int i;

   Xil_ICacheEnable();
   Xil_DCacheEnable();
   printf("---Entering main---\n\r");
   
   SSM2603_init();
   
   pI2S->CTL = RATE_44100|ADC_MUTE;
   
   while (1) {
      for (i=0;i<(sizeof(wav_tbl)/4);i++) {
          while ((pI2S->INT & 0x100) == 0);
          pI2S->DAC_DATA = wav_tbl[i];
      }
   }

   printf("---Exiting main---\n\r");
   Xil_DCacheDisable();
   Xil_ICacheDisable();
   return 0;
}
