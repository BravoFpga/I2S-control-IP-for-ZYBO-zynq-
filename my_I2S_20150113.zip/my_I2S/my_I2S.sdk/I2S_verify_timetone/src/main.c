
#include <stdio.h>
#include "xparameters.h"
#include "xil_cache.h"
#include "my_i2s.h"
#include "timetone.h"

struct st_I2S *pI2S = (struct st_I2S *)XPAR_I2S_CTL_0_BASEADDR;

void SSM2603_REGWRT(u32 Ra, u32 Wd)
{
   pI2S->I2C_RA = (Ra<<1) | ((Wd >> 8) & 1);
   pI2S->I2C_RD = Wd;
   pI2S->I2C_CA = I2C_WRITE;
   while (pI2S->I2C_ST);
}

u32 SSM2603_REGRD(u32 Ra)
{
   pI2S->I2C_RA = Ra<<1;
   pI2S->I2C_RD = 0;
   pI2S->I2C_CA = I2C_READ;
   while (pI2S->I2C_ST);
   return pI2S->I2C_RD;
}

void SSM2603_init()
{
   int i;

   /*
   // dump
   for (i=0;i<0x13;i=(i==0x09)? 0x0F:i+1)
   {
       printf("SSM2603.R%d = %08X\n",i, SSM2603_REGRD(i));
   }
   */

   SSM2603_REGWRT(0x06, 0x72); // Power
   SSM2603_REGWRT(0x0F, 0x00); // Reset

   SSM2603_REGWRT(0x00, 0x97); // Lch ADC input volume
   SSM2603_REGWRT(0x01, 0x97); // Rch ADC input volume
   SSM2603_REGWRT(0x02, 0x7F); // Lch DAC volume
   SSM2603_REGWRT(0x03, 0x7F); // Rch DAC volume
   SSM2603_REGWRT(0x04, 0x10); // Analog audio path
   SSM2603_REGWRT(0x05, 0x00); // Digital audio path
   SSM2603_REGWRT(0x07, 0x02); // Digital audio I/F
   SSM2603_REGWRT(0x08, 0x00); // Sampling rate (48KHz)
   SSM2603_REGWRT(0x10, 0x7B); // ALC Control 1
   SSM2603_REGWRT(0x11, 0x32); // ALC Control 2
   SSM2603_REGWRT(0x12, 0x00); // Noise gate

   // wait (approx.) 100ms
   // usleep(100000);
   for (i=0;i<1700;i++) SSM2603_REGRD(0x09);

   SSM2603_REGWRT(0x09, 0x01); // Active
   SSM2603_REGWRT(0x06, 0x62); // Out->on

   /*
   // dump
   for (i=0;i<0x13;i=(i==0x09)? 0x0F:i+1)
   {
       printf("SSM2603.R%d = %08X\n",i, SSM2603_REGRD(i));
   }
   */
}

int main() 
{
   int i,ii;
   u32 wv;
   //struct st_I2S *pI2S = (struct st_I2S *)XPAR_I2S_CTL_0_BASEADDR;

   Xil_ICacheEnable();
   Xil_DCacheEnable();
   printf("---Entering main---\n\r");
   
   {
/*
	   printf("CTL = %08x\n", pI2S->CTL);
	   printf("INT = %08x\n", pI2S->INT);
	   printf("DAC_DATA = %08x\n", pI2S->DAC_DATA);
	   printf("ADC_DATA = %08x\n", pI2S->ADC_DATA);
	   printf("DAC_BGN  = %08x\n", pI2S->DAC_BGN);
	   printf("DAC_END  = %08x\n", pI2S->DAC_END);
	   printf("DAC_THR  = %08x\n", pI2S->DAC_THR);
	   printf("DAC_CUR  = %08x\n", pI2S->DAC_CUR);
	   printf("ADC_BGN  = %08x\n", pI2S->ADC_BGN);
	   printf("ADC_END  = %08x\n", pI2S->ADC_END);
	   printf("ADC_THR  = %08x\n", pI2S->ADC_THR);
	   printf("ADC_CUR  = %08x\n", pI2S->ADC_CUR);
	   printf("I2C_RA   = %08x\n", pI2S->I2C_RA);
	   printf("I2C_RD   = %08x\n", pI2S->I2C_RD);
	   printf("I2C_CA   = %08x\n", pI2S->I2C_CA);
	   printf("I2C_ST   = %08x\n", pI2S->I2C_ST);
*/
	   SSM2603_init();

	   //pI2S->CTL = RATE_48000|ADC_MUTE;
	   pI2S->CTL = RATE_44100|ADC_MUTE;

	   for (ii=0;ii<(sizeof(wav_tbl)/4);ii++) {
		   wv = wav_tbl[ii];
	       while ((pI2S->INT & 0x100) == 0);
	       pI2S->DAC_DATA = wv;
	   }
   }

   printf("---Exiting main---\n\r");
   Xil_DCacheDisable();
   Xil_ICacheDisable();
   return 0;
}
