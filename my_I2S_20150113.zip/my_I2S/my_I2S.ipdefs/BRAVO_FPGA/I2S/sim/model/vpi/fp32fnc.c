#include	<stdio.h>
#include	<math.h>

#ifdef	_MAKE_VPI_TASK_
#include	<vpi_user.h>
#else
#include	<veriuser.h>
#ifdef _GPLCVER_
#include	<cv_veriuser.h>
#endif
#endif

typedef	int si32;
typedef unsigned int ui32;
typedef float fp32;
typedef union {
	 fp32	f;
	 ui32	c;
} fc32;

enum FuncType {FT_ADD, FT_SUB, FT_MUL, FT_DIV, FT_MOD, FT_SQRT, FT_LOG};
static char ft_add  = FT_ADD ;
static char ft_sub  = FT_SUB ;
static char ft_mul  = FT_MUL ;
static char ft_div  = FT_DIV ;
static char ft_mod  = FT_MOD ;
static char ft_sqrt = FT_SQRT;
static char ft_log  = FT_LOG ;

//
// $fp32_xxx(inA,inB,outY);
//
static PLI_INT32 fp32_2opc(char *data)
{
	fc32	inA,inB,outY;

#ifdef  _MAKE_VPI_TASK_
	s_vpi_value value;
	value.format = vpiIntVal;

	vpiHandle argv   = vpi_iterate(vpiArgument, vpi_handle(vpiSysTfCall, 0));
	vpiHandle h_inA  = vpi_scan(argv);
	vpiHandle h_inB  = vpi_scan(argv);
	vpiHandle h_outY = vpi_scan(argv);

	vpi_get_value(h_inA, &value);
	inA.c = value.value.integer;

	vpi_get_value(h_inB, &value);
	inB.c = value.value.integer;

#else
	inA.c = tf_getp(1);
	inB.c = tf_getp(2);
#endif
	switch (*data) {
	  case FT_ADD:// add
		 outY.f = inA.f + inB.f;
		 break;
	  case FT_SUB:// sub
		 outY.f = inA.f - inB.f;
		 break;
	  case FT_MUL:// mul
		 outY.f = inA.f * inB.f;
		 break;
	  case FT_DIV:// div
		 outY.f = inA.f / inB.f;
		 break;
	  case FT_MOD:// mod
		 outY.f = modff(inA.f,&inB.f);
		 break;
	  default:
		 outY.f = 0.0f;
		 break;
	}
#ifdef  _MAKE_VPI_TASK_
	value.format = vpiIntVal;
	value.value.integer = outY.c;
	vpi_put_value(h_outY, &value, 0, vpiNoDelay);
	vpi_free_object(argv);
#else
	tf_putp(3,outY.c);
#endif
	return (0);
}

//
// $fp32_xxx(inA,outY);
//
static PLI_INT32 fp32_1opc(char *data)
{
	fc32	inA,outY;

#ifdef  _MAKE_VPI_TASK_
	s_vpi_value value;
	value.format = vpiIntVal;

	vpiHandle argv   = vpi_iterate(vpiArgument, vpi_handle(vpiSysTfCall, 0));
	vpiHandle h_inA  = vpi_scan(argv);
	vpiHandle h_outY = vpi_scan(argv);

	vpi_get_value(h_inA, &value);
	inA.c = value.value.integer;

#else
	inA.c = tf_getp(1);
#endif
	switch (*data) {
	  case FT_SQRT:// sqrt
		 outY.f = sqrtf(inA.f);
		 break;
	  case FT_LOG:// log
		 outY.f = logf(inA.f);
		 break;
	  default:
		 outY.f = 0.0f;
		 break;
	}
#ifdef  _MAKE_VPI_TASK_
	value.format = vpiIntVal;
	value.value.integer = outY.c;
	vpi_put_value(h_outY, &value, 0, vpiNoDelay);
	vpi_free_object(argv);
#else
	tf_putp(2,outY.c);
#endif
	return (0);
}

#ifdef _MAKE_VPI_TASK_
/*
 *  howto make a vpi library for Icarus verilog
 *  
 *  gcc -std=gnu99 -D_MAKE_VPI_TASK_ -I $ICARUS_HOME/include/iverilog -fPIC -Wall -Wshadow -g -O2 -c fp32fnc.c
 *  gcc -lvpi -L $ICARUS_HOME/lib -shared -o fp32fnc.vpi fp32fnc.o 
 *  
 */
static  s_vpi_systf_data tf_data[] = {
        {vpiSysTask,0,"$fp32_add" ,fp32_2opc,NULL,NULL,&ft_add },
        {vpiSysTask,0,"$fp32_sub" ,fp32_2opc,NULL,NULL,&ft_sub },
        {vpiSysTask,0,"$fp32_mul" ,fp32_2opc,NULL,NULL,&ft_mul },
        {vpiSysTask,0,"$fp32_div" ,fp32_2opc,NULL,NULL,&ft_div },
        {vpiSysTask,0,"$fp32_mod" ,fp32_2opc,NULL,NULL,&ft_mod },
        {vpiSysTask,0,"$fp32_sqrt",fp32_1opc,NULL,NULL,&ft_sqrt},
        {vpiSysTask,0,"$fp32_log" ,fp32_1opc,NULL,NULL,&ft_log },
        {0}};

static void task_registration()
{
        p_vpi_systf_data ptr = tf_data;
        while (ptr->type) {
	  vpi_register_systf(ptr++);
        }
        return;
}

void (*vlog_startup_routines[])() = {
      task_registration,
      0
};

/*  dummy +loadvpi= bootstrup routine - mimics old style exec all routines */
/*  in standard PLI vlog_startup_routines */
void vpi_compat_bootstrap(void)
{
  int i;
  for (i=0;;i++) 
  {
    if (vlog_startup_routines[i] == NULL) break;
    vlog_startup_routines[i]();
  }
}
#else

#ifdef _GPLCVER_
s_tfcell veriusertfs[] = {
 /* type, data, *checktf, *sizetf, *callt, *misctf, *tfname, forwref */
 {usertask, &ft_add , 0, 0, fp32_2opc,  0, "$fp32_add" ,  0},
 {usertask, &ft_sub , 0, 0, fp32_2opc,  0, "$fp32_sub" ,  0},
 {usertask, &ft_mul , 0, 0, fp32_2opc,  0, "$fp32_mul" ,  0},
 {usertask, &ft_div , 0, 0, fp32_2opc,  0, "$fp32_div" ,  0},
 {usertask, &ft_mod , 0, 0, fp32_2opc,  0, "$fp32_mod" ,  0},
 {usertask, &ft_sqrt, 0, 0, fp32_1opc,  0, "$fp32_sqrt",  0},
 {usertask, &ft_log , 0, 0, fp32_1opc,  0, "$fp32_log" ,  0},
 {0}
};

s_tfcell *pli1_compat_bootstrap(void)
{
	return (veriusertfs);
}
#endif

#endif
