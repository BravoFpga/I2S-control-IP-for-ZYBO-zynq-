// =================================================================================================
// Copyright (C) 2012- Hirokatsu Sunakawa (hc16804@yahoo.co.jp)
//                                                              
//    This source code is free software; you can redistribute it
//    and/or modify it under the terms of the GNU Lesser General
//    Public License as published by the Free Software Foundation;
//    either version 2.1 of the License, or (at you option) any
//    later version.
//
//    This source is distributed in the hope that it will be useful,
//    but WITHOUT ANY WARRANTY; without even the implied warranty of
//    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
//    GNU General Public License for more details.
//
//    You should have received a copy of the GNU General Public License
//    along with this program; if not, write to the Free Software
//    Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA
//
// =================================================================================================
// $Id: arc_tblgen.c,v 1.1.1.1 2013/02/10 13:31:58 surabu-ya Exp $
// =================================================================================================
#include <stdio.h>
#include <math.h>
/*
 * how to compile
 * gcc arc_tblgen.c -lm
 *
 */

typedef float fp32;
typedef unsigned int ui32;

typedef union {
	  fp32 f;
	  ui32 c;
} fc32;


main()
{
   FILE *fp;
   ui32 i;
   double s;
   fc32 fxp_cnv;

   fp = fopen("arc_rom.mif","w");
   fprintf(fp,"// memory_initialization_radix = 16;\n");
   fprintf(fp,"// memory_initialization_vector =\n");

#define DIVN 2048
   s = (2.0*M_PI)/DIVN;

   for (i=1;i<=(DIVN/4);i++) {
     //fxp_cnv.f = 1.0f * sinf(s * (double)i);
     fxp_cnv.f = 0.9999999f * sinf(s * (double)i);
     fprintf(fp,"%08X\n",fxp_cnv.c);
   }

   fclose(fp);
}
