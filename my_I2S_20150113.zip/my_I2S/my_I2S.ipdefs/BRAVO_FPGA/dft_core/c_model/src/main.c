const char *copyright = {\
"\n\
Copyright 2012-2015 Hirokatsu Sunakawa (hc16804@yahoo.co.jp)\n\
\n\
  This program is free software; you can redistribute it and/or modify\n\
  it under the terms of the GNU General Public License as published by\n\
  the Free Software Foundation; either version 2 of the License, or\n\
  (at your option) any later version.\n\
\n\
  This program is distributed in the hope that it will be useful,\n\
  but WITHOUT ANY WARRANTY; without even the implied warranty of\n\
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n\
  GNU General Public License for more details.\n\
\n\
  You should have received a copy of the GNU General Public License along\n\
  with this program; if not, write to the Free Software Foundation, Inc.,\n\
  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.\n\
\n\
\n\
\n\
"};
#include  <sys/time.h>
#include  "common.h"

const char *program_name = "my_dft";

#define	PRG_VERSION (0.4)
#define	DATECODE    ("20150110")
#define	AUTHOR	    ("Hirokatsu Sunakawa")

const char *usage = {\
"Usage:\n\
 \n\
  my_dft -h ................................ display this messages\n\
  my_dft -l ................................ display copyright\n\
  my_dft -i filename [-o 0..4] [-r n] ...... play\n\
\n\
  -o : output data type\n\
       0 ... absolute value in float. (default)\n\
       1 ... absolute value in hex code.\n\
       2 ... complex value in float.\n\
       3 ... complex value in hex code.\n\
       4 ... absolute value in float [dB].\n\
      99 ... major variables in hex code.\n\
  -r : output rate\n\
       0 ... every 2048 samples (default)\n\
       n ... every n samples\n\
\n\
"};

int main (int argc, char **argv)
{
  char *fname = 0;
  struct timeval start_tv,end_tv;
  struct sc_wav_file *wav_file;
  int i,
      otype=OT_ABS_FLOAT,
      orate=DIVN;

  if (argc <= 1) {
      my_printf(NONE,"%s",usage);
      exit (0);
  }

  for (i = 1; i < argc; i++) {
     if (argv[i][0] == '-') {
       switch (argv[i][1]) {
	 case 'i':
	   fname = argv[++i];
	   break;

	 case 'o':
	   sscanf(argv[++i],"%d",&otype);
	   if ((otype < OT_ABS_FLOAT || otype > OT_ABS_FLOAT_dB ) && otype != 99) {
	     my_printf(ERROR,"-o %d\n",otype);
	     exit (-1);
	   }
	   break;

	 case 'r':
	   sscanf(argv[++i],"%d",&orate);
	   if (orate < 0 || orate > DIVN) {
	     my_printf(ERROR,"-o %d\n",orate);
	     exit (-1);
	   }
	   if (orate == 0) orate = DIVN;
	   break;

	 case 'l':
  	   my_printf(NONE,"\n%s Ver %0.2f (%s)\n", program_name, PRG_VERSION, DATECODE);
	   my_printf(NONE,"%s", copyright);
	   exit (0);
	   break;

	 case 'h':
	 default:
      	   my_printf(NONE,"%s",usage);
	   exit (0);
       }
     } else {
       my_printf(ERROR,"illegal option, i=%d, argv[i]=%s\n", i, argv[i]);
       my_printf(NONE,"%s",usage);
       exit (-1);
     }
  }

  my_printf(NONE,"\n");
  my_printf(NONE,"### %s Ver %0.2f (%s)###\n\n", program_name, PRG_VERSION, DATECODE);

  wav_file = wav_file_read(fname);

  init_arc();

  my_printf(NONE,"Sampling Rate = %.1f[KHz]\n",(float)wav_file->fmt_chunk->SamplingRate/1000.0f);
  my_printf(NONE,"Data Length = %d[samples]\n",wav_file->nSample);
  my_printf(NONE,"Start ...\n");
  gettimeofday(&start_tv,NULL);
  dft_proc(wav_file->PCM,wav_file->nSample,otype,orate,(float)wav_file->fmt_chunk->SamplingRate/(float)DIVN);
  gettimeofday(&end_tv,NULL);
  my_printf(INFO,"Execution Time = %.3f seconds\n", 
  	(((double)end_tv.tv_sec + (double)end_tv.tv_usec * 1e-6) 
			- ((double)start_tv.tv_sec + (double)start_tv.tv_usec * 1e-6)));
  return 0;
}
