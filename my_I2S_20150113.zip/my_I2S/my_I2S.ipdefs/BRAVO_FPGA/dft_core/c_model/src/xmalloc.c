/*
 *  Copyright 2011-2015 Hirokatsu Sunakawa <hc16804@yahoo.co.jp>
 *                                                              
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
 */
#include "common.h"

void *
xmalloc (size_t num)
{
  void *new = malloc (num);
  if (!new)
    my_printf(FATAL,"Memory exhausted");
  return new;
}

void *
xrealloc (void *p, size_t num)
{
  void *new;
  if (!p)
    return xmalloc (num);

  new = realloc (p, num);
  if (!new)
    my_printf(FATAL,"Memory exhausted");

  return new;
}

void *
xcalloc (size_t num, size_t size)
{
  void *new = xmalloc (num * size);
  memset (new, 0, num * size);
  return new;
}
