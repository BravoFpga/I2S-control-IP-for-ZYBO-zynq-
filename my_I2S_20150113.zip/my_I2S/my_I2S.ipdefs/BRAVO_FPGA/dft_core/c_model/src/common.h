#ifndef COMMON_H
#define COMMON_H
/*
 *  Copyright 2012-2015 Hirokatsu Sunakawa <hc16804@yahoo.co.jp>
 *                                                              
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <termios.h>
#include <errno.h>

extern void * xmalloc (size_t num);
extern void * xrealloc (void *p, size_t num);
extern void * xcalloc (size_t num, size_t size);

#define XCALLOC(type, num) \
        ((type *) xcalloc ((num), sizeof(type)))
#define	XMALLOC(type, num)   \
	((type *) xmalloc ((num) * sizeof(type)))
#define	XREALLOC(type, p, num)   \
	((type *) xrealloc ((p), (num) *  sizeof(type)))
#define XFREE(stale)	do { \
	if (stale) { free (stale); stale = 0; } \
	                                      } while (0)

#define	msleep(t) usleep((unsigned long)(t * 1000L));

#include "error.h"
#include "wav.h"
#include "my_dft.h"

#endif
