/*
 *  Copyright 2012- Hirokatsu Sunakawa <hc16804@yahoo.co.jp>
 *                                                              
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
 */
#include "common.h"

static fp32 arc_tbl[DIVN];
static lr_data lr0 = {0};
static sc_complex c0 = {0.0f, 0.0f};
static sc_complex sfp_l[DIVN/2];
static sc_complex sfp_r[DIVN/2];
static char obuff[1024*128];

#define PRE_SET(p,xd,sfp) ((p==0)? ((sc_complex){(c0.r +xd.f),c0.i }):\
         			   ((sc_complex){(sfp.r+xd.f),sfp.i}))

static void dump_result (int p, int length, lr_data xp, 
			 fc32 xd_r, fc32 xd_l, int orate, int otype, fp32 fstep);

void init_arc(void)
{
   double stp;
   int  f;

   stp = (2*M_PI)/DIVN;
   for (f=0;f<=DIVQ;f++) {
     arc_tbl[f] = sinf(stp*(double)f);
#ifdef HIGH_SPEED_VERSION
     arc_tbl[(DIVN/2)+f] = -1.0f * arc_tbl[f];
#endif
   }

#ifdef HIGH_SPEED_VERSION
   for (f=1;f<DIVQ;f++) {
     arc_tbl[(DIVN/2)-f] = arc_tbl[f];
     arc_tbl[DIVN-f] = -1.0f * arc_tbl[f];
   }
#endif
}

#ifdef HIGH_SPEED_VERSION
  #define get_arc(omega) \
	((sc_complex){arc_tbl[DIVQ+(omega%DIVN)], arc_tbl[omega%DIVN]});

#else
inline static sc_complex get_arc(int omega)
{
   sc_complex rtn;
   int somega, comega, sc, ss;

   sc = ss = 1;
   comega = somega = omega%(DIVN/4);

   switch ((omega/DIVQ)&3) {
      case 0: comega = DIVQ-comega;
      	      break;
      case 1: somega = DIVQ-somega;
              sc = -1;
      	      break;
      case 2: comega = DIVQ-comega;
              sc = -1;
              ss = -1;
      	      break;
      case 3: somega = DIVQ-somega;
              ss = -1;
      	      break;
   }
 
   rtn.r = sc * arc_tbl[comega];
   rtn.i = ss * arc_tbl[somega];
   return rtn;
}
#endif


#ifdef HIGH_SPEED_VERSION
//
// little high-speed version
//
void dft_proc (lr_data in_stream[], int length, int otype, int orate, fp32 fstep) 
{
   int     p,f;
   lr_data xp_N;
   fc32    xd_l,xd_r;
   sc_complex arc[4],pre[4];

   for (p=0;p<length;p++) {
     /* calculate of (xp - xp_N) and normalize */
     xp_N = (p<DIVN)? lr0:in_stream[p-DIVN];
     xd_l.f = (fp32)(in_stream[p].p.l - xp_N.p.l)/32768.0f;
     xd_r.f = (fp32)(in_stream[p].p.r - xp_N.p.r)/32768.0f;

     /* calculate of spectrum */
     for (f=0;f<(DIVN/2);f+=4) {
       arc[0] = get_arc(f);
       arc[1] = get_arc(f+1);
       arc[2] = get_arc(f+2);
       arc[3] = get_arc(f+3);

       //-- LEFT --
       pre[0] = PRE_SET(p,xd_l,sfp_l[f]);
       pre[1] = PRE_SET(p,xd_l,sfp_l[f+1]);
       pre[2] = PRE_SET(p,xd_l,sfp_l[f+2]);
       pre[3] = PRE_SET(p,xd_l,sfp_l[f+3]);

       sfp_l[f  ] = CMUL(pre[0],arc[0]);
       sfp_l[f+1] = CMUL(pre[1],arc[1]);
       sfp_l[f+2] = CMUL(pre[2],arc[2]);
       sfp_l[f+3] = CMUL(pre[3],arc[3]);

       //-- RIGHT --
       pre[0] = PRE_SET(p,xd_r,sfp_r[f]);
       pre[1] = PRE_SET(p,xd_r,sfp_r[f+1]);
       pre[2] = PRE_SET(p,xd_r,sfp_r[f+2]);
       pre[3] = PRE_SET(p,xd_r,sfp_r[f+3]);

       sfp_r[f  ] = CMUL(pre[0],arc[0]);
       sfp_r[f+1] = CMUL(pre[1],arc[1]);
       sfp_r[f+2] = CMUL(pre[2],arc[2]);
       sfp_r[f+3] = CMUL(pre[3],arc[3]);
     }
     dump_result(p, length, in_stream[p], xd_r, xd_l, orate, otype, fstep);
   }
}

#else

void dft_proc (lr_data in_stream[], int length, int otype, int orate, fp32 fstep)
{
   int     p,f;
   lr_data xp_N;
   fc32    xd_l,xd_r;
   sc_complex arc,pre;

   for (p=0;p<length;p++) {
     /* calculate of (xp - xp_N) and normalize */
     xp_N = (p<DIVN)? lr0:in_stream[p-DIVN];
     xd_l.f = (fp32)(in_stream[p].p.l - xp_N.p.l)/32768.0f;
     xd_r.f = (fp32)(in_stream[p].p.r - xp_N.p.r)/32768.0f;

     /* calculate of spectrum */
     for (f=0;f<DIVN/2;f++) {
       arc = get_arc(f);

       pre = PRE_SET(p,xd_l,sfp_l[f]);
       sfp_l[f] = CMUL(pre,arc);

       pre = PRE_SET(p,xd_r,sfp_r[f]);
       sfp_r[f] = CMUL(pre,arc);
/*
       pre = (p==0)? c0:sfp_l[f];
       sfp_l[f].r = (pre.r + xd_l.f)*arc.r - pre.i*arc.i;
       sfp_l[f].i = (pre.r + xd_l.f)*arc.i + pre.i*arc.r;

       pre = (p==0)? c0:sfp_r[f];
       sfp_r[f].r = (pre.r + xd_r.f)*arc.r - pre.i*arc.i;
       sfp_r[f].i = (pre.r + xd_r.f)*arc.i + pre.i*arc.r;
*/
     }

     dump_result(p, length, in_stream[p], xd_r, xd_l, orate, otype, fstep);
   }
}

#endif

static void dump_result (int p, int length, lr_data xp, fc32 xd_r, fc32 xd_l, int orate, int otype, fp32 fstep)
{
   int   f,i,fd;
   fc32  pwr_l,pwr_r;
   sc_complex arc;
   fp32 freq;

//   if (orate == OR_ALWAYS || (p%DIVN) == 0 || p == (length-1)) {
   if ((p%orate) == 0 || p == (length-1)) {
      //i = (orate == OR_ALWAYS)? p:p/DIVN;
      i = p/orate;
      sprintf(obuff,"%d.spc",i);
      fd = creat(obuff,S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);

      i = 0;
      if (otype == OT_ABS_FLOAT || otype == OT_ABS_CODE) {
        i += sprintf(&obuff[i], "# freq     pwr_r     pwr_l\n");
      } else if (otype == OT_CPX_FLOAT || otype == OT_CPX_CODE) {
        i += sprintf(&obuff[i], "# sfp_r.r   sfp_r.i   sfp_l.r   sfp_l.i\n");
      } else if (otype == OT_DBG_CODE) {
        i += sprintf(&obuff[i],
          "#xp_r xp_l xd_r    xd_l     arc.r    arc.i    sfp_r.r  sfp_r.i  sfp_l.r  sfp_l.i  pwr_r    pwr_l\n");
      }
      for (f=0,freq=0.0f;f<DIVN/2;f++,freq+=fstep) {
         pwr_l.f = CABS(sfp_l[f]);
         pwr_r.f = CABS(sfp_r[f]);

         if (otype == OT_ABS_FLOAT) {
           i += sprintf(&obuff[i],"%f %+f %+f\n",freq, pwr_r.f,pwr_l.f);
         } else if (otype == OT_ABS_FLOAT_dB) {
           i += sprintf(&obuff[i],"%+f %+f\n",20*log10f(pwr_r.f),20*log10f(pwr_l.f));
         } else if (otype == OT_ABS_CODE) {
           i += sprintf(&obuff[i],"%f  %08X  %08X\n",freq, pwr_r.c,pwr_l.c);
         } else if (otype == OT_CPX_FLOAT) {
           i += sprintf(&obuff[i],"%+f %+f %+f %+f\n",sfp_r[f].r,sfp_r[f].i,sfp_l[f].r,sfp_l[f].i);
         } else if (otype == OT_CPX_CODE) {
           i += sprintf(&obuff[i]," %08X  %08X  %08X  %08X\n",
      				GET_FPCODE(sfp_r[f].r),GET_FPCODE(sfp_r[f].i),
      				GET_FPCODE(sfp_l[f].r),GET_FPCODE(sfp_l[f].i));
         } else {
     	   arc = get_arc(f);
           i += sprintf(&obuff[i],
           		"%04X %04X %08X %08X %08X %08X %08X %08X %08X %08X %08X %08X\n",
           			0xffff&xp.p.r,
      				0xffff&xp.p.l,
          			xd_r.c, xd_l.c,
      				GET_FPCODE(arc.r), GET_FPCODE(arc.i),
      				GET_FPCODE(sfp_r[f].r),GET_FPCODE(sfp_r[f].i),
      				GET_FPCODE(sfp_l[f].r),GET_FPCODE(sfp_l[f].i),
      				pwr_r.c,pwr_l.c);
         }
      }
      i = write(fd,obuff,i);
      close(fd);
   }
}
