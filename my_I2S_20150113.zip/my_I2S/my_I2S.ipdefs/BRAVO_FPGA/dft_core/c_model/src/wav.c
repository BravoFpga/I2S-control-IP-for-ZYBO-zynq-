#include "common.h"

struct sc_wav_file *wav_file_read(char *fname)
{
    int fd;

    struct sc_wav_file *wav_file = 
   	(struct sc_wav_file *)xcalloc(1, sizeof(struct sc_wav_file));

    if ((fd = open(fname,O_RDONLY)) == -1) {
      free(wav_file);
      my_printf(FATAL,"can not open a file %s\n",fname);
    }
    wav_file->file_size = lseek(fd, 0, SEEK_END);
    lseek(fd, 0, SEEK_SET);

    wav_file->raw_data = (char *)xmalloc(wav_file->file_size);

    if (read(fd, wav_file->raw_data, wav_file->file_size) < 0) {
      my_printf(FATAL,"\ncan not read a file %s\n",fname);
    }
    close (fd);

    int p = 12;
    do {
      if (strncasecmp(&wav_file->raw_data[p],"fmt ",4) == 0) {
         wav_file->fmt_chunk = (struct sc_fmt_chunk *)&wav_file->raw_data[p];
	 p = p + wav_file->fmt_chunk->nBytes + 8;
      } else if (strncasecmp(&wav_file->raw_data[p],"list ",4) == 0) {
         wav_file->list_chunk = (struct sc_list_chunk *)&wav_file->raw_data[p];
	 p = p + wav_file->list_chunk->nBytes + 8;
      } else if (strncasecmp(&wav_file->raw_data[p],"data",4) == 0) {
         wav_file->data_chunk = (struct sc_data_chunk *)&wav_file->raw_data[p];
	 break;
      } else {
        p++;
      }
    } while (p < (wav_file->file_size-4));

    if (wav_file->fmt_chunk == 0) {
       my_printf(FATAL,"\nThere is no format information in %s.\n",fname);
    }

    if (wav_file->data_chunk == 0) {
       my_printf(FATAL,"\nThere is no pcm data in %s.\n",fname);
    }

    wav_file->nSample = wav_file->data_chunk->nBytes /
    			  ((wav_file->fmt_chunk->BitPerSample * wav_file->fmt_chunk->nChannel) / 8);
    wav_file->PCM = &wav_file->data_chunk->PCM;

    return wav_file;
}
