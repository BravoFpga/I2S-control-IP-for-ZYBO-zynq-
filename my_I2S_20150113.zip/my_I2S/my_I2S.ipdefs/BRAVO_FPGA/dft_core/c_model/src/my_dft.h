/*
 *  Copyright 2012-2015 Hirokatsu Sunakawa <hc16804@yahoo.co.jp>
 *                                                              
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
 */
#ifndef MY_DFT_H
#define MY_DFT_H

#include <stdio.h>
#include <strings.h>
#include <math.h>

#define	DIVN	2048
#define DIVQ   (DIVN/4)

typedef float fp32;
typedef int si32;
typedef unsigned int ui32;

typedef union {
    fp32 f;
    ui32 c;
} fc32;

#define GET_FPCODE(x) ((fc32)x).c

typedef struct {
   fp32 r;
   fp32 i;
} sc_complex;

#define CABS(cpx) sqrtf(powf(cpx.r,2)+powf(cpx.i,2))

#define CADD(a,b) ((sc_complex){(a.r + b.r),(a.i + b.i)}) 

#define CSUB(a,b) ((sc_complex){(a.r - b.r),(a.i - b.i)}) 

#define CMUL(a,b) ((sc_complex){(a.r * b.r - a.i * b.i),\
                                (a.r * b.i + a.i * b.r)}) 


#define	OR_DIVN    (0)
#define	OR_ALWAYS  (1)

#define OT_DBG_CODE     (99)
#define OT_ABS_FLOAT    (0)
#define OT_ABS_CODE     (1)
#define OT_CPX_FLOAT    (2)
#define OT_CPX_CODE     (3)
#define OT_ABS_FLOAT_dB (4)

void init_arc(void);
void dft_proc (lr_data in_stream[], int length, int otype, int orate, fp32 fstep);

#endif
