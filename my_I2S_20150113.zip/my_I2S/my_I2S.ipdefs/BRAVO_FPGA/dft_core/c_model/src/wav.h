/*
 *  Copyright 2012-2015 Hirokatsu Sunakawa <hc16804@yahoo.co.jp>
 *                                                              
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
 */
#ifndef WAV_H
#define WAV_H

#define	FMT_UNKNOWN		0x0000
#define	FMT_PCM		        0x0001
#define	FMT_MS_ADPCM	        0x0002
#define	FMT_IBM_CSVD	        0x0005
#define	FMT_A_Law   	        0x0006
#define	FMT_u_Law   	        0x0007
#define	FMT_OKI_ADPCM	        0x0010
#define	FMT_IMA_DVI_ADPCM    	0x0011
#define FMT_MediaSpace_ADPCM 	0x0012
#define	FMT_Sierra_ADPCM	0x0013
#define	FMT_G723_ADPCM		0x0014
#define	FMT_DIGISTD		0x0015
#define	FMT_DIGIFIX		0x0016
#define	FMT_YAMAHA_ADPCM	0x0020
#define	FMT_SONARC		0x0021
#define	FMT_TrueSpeech		0x0022
#define	FMT_EchoSpeech1		0x0023
#define	FMT_AF36		0x0024
#define	FMT_Apix		0x0025
#define	FMT_AF10		0x0026
#define	FMT_AC2			0x0030
#define	FMT_GSM_610		0x0031
#define	FMT_ANTEX_ADPCM		0x0033
#define	FMT_VQLPC		0x0034
#define	FMT_DIGIREAL		0x0035
#define	FMT_DIGIADPCM		0x0036
#define	FMT_CR10		0x0037
#define	FMT_G721_ADPCM		0x0040
#define	FMT_IBM_u_Law		0x0101
#define	FMT_IBM_A_Law		0x0102
#define	FMT_IBM_ADPCM		0x0103
#define	FMT_CreativeLabs_ADPCM	0x0200
#define	FMT_FM_TOWNS		0x0300
#define	FMT_Olivetti_GSM	0x1000
#define	FMT_Olivetti_ADPCM	0x1001
#define	FMT_Olivetti_CELP 	0x1002
#define	FMT_Olivetti_SBC  	0x1003
#define	FMT_Olivetti_OPR  	0x1004

typedef union {
    int lr;
    struct {
      int l:16;
      int r:16;
    } p;
} lr_data;

struct sc_wav_hdr {
  char 	  RIFF[4]; // "RIFF"
  int  	  nTotal;
  char 	  WAVE[4]; // "WAVE"
};

struct sc_fmt_chunk {
  char    ID[4]; // "fmt "
  int	  nBytes;
  short	  FormatId;
  short   nChannel;
  int	  SamplingRate;
  int	  DataSpeed;
  short	  BlockSize;
  short	  BitPerSample;
  short   ExtendSize;
  char    ExtendArea[];
};

struct sc_data_chunk {
  char    ID[4]; // "data"
  int	  nBytes;
  lr_data PCM;
};

struct sc_info_chunk {
  char    ID[4]; // INFO
  struct {
    char ID[4]; // INAM, IART, ICMT, ICRD, ...
    int  nBytes;
    char Data[];
  } info[];
};

struct sc_list_chunk {
  char	  ID[4];// "list"
  int	  nBytes;
  struct sc_info_chunk info_chunk[];
};

struct sc_wav_file {
  int  fd;
  off_t file_size;
  char *raw_data;
  struct sc_fmt_chunk  *fmt_chunk;
  struct sc_list_chunk *list_chunk;
  struct sc_data_chunk *data_chunk;
  int    nSample;
  lr_data *PCM;
};

struct sc_wav_file *wav_file_read(char *fname);

#endif
